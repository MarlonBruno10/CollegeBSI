package ArvoreBinariaDeBusca;

public class ArvoreVaziaException extends Exception{
    public ArvoreVaziaException() {
        super("A árvore está vazia.");
    }
}

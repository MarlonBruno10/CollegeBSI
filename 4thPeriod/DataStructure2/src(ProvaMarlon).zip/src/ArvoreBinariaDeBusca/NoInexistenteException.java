package ArvoreBinariaDeBusca;

//
public class NoInexistenteException extends Exception{
    public NoInexistenteException(){
        super("No inexistente!");
    }
}

package Arvore;

public class No {
    int dado;
    No esquerda;
    No direita;

    public No(){
        this.dado = dado;
        esquerda = null;
        direita = null;
    }

}
